﻿namespace System.Windows
{
    internal class SystemParameters
    {
    }
}