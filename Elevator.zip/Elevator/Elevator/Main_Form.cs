﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Elevator
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
            Elevator_Database db = new Elevator_Database();
            //MessageBox.Show(db.GetCurrentFloor());
            //db.SetCurrentFloor(1);
            
            

        }

    

        

        private void elevator_floor1_btn_down_Click(object sender, EventArgs e)
        {
            timer1.Start();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Top += 5;
            if (pictureBox1.Bounds.IntersectsWith(Floor0_tableLayoutPanel.Bounds))
            {
                panel2.Controls.Add(pictureBox1);
                pictureBox1.Top = 0;
                timer1.Stop();
                timer2.Start();
                
            

            }
            


        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            pictureBox1.Top += 5;
            if (pictureBox1.Bounds.IntersectsWith(radioButton1.Bounds))
            {
                

                pictureBox1.Dock = DockStyle.Bottom;

                timer2.Stop();
                



            }

        }
    }
}
