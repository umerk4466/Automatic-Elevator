﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Elevator
{
     class Elevator_Database
    {
        // Function to retun current floor of the Elevator from Database
        internal string GetCurrentFloor() {
            string Floor = "No Current Floor Records Available";
            var DBPath = Application.StartupPath + "\\Elevator_DB_2000.mdb";
            OleDbConnection conn = new OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + DBPath);
            try
            {
                // Get Current Floor Number From Database
                string queryString = "SELECT Floor_number FROM Floors WHERE Floor_id=(SELECT Floor_id FROM Current_Floor WHERE Current_Floor_id=(SELECT MAX(Current_Floor_id) FROM Current_Floor))";

                OleDbCommand command = new OleDbCommand(queryString, conn);
                conn.Open();
                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Floor = reader.GetInt32(0).ToString();
                }
                
                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!!! Something is wrong with Database");
            }

            return Floor;
        }

        // Function to Set current floor of the Elevator
        internal void SetCurrentFloor(int State) {
            if (State == 1 || State == 2)
            {
                SetFloorToDatabase(State);
            }
            else {
                MessageBox.Show("Error!!! You only can set Elevator to floor 1 or 2");
            }
        }
        
        
        // Function to Set the Current Floor of the Elevator in the database
        private void SetFloorToDatabase(int State)
        {
            var DBPath = Application.StartupPath + "\\Elevator_DB_2000.mdb";
            OleDbConnection conn = new OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + DBPath);

            try
            {
                // Set Floor State to the Database with current date and time
                string date_time = DateTime.Now.ToString("dd-MM-yyyy 'at' h:mm:ss tt");
                string queryString = "INSERT INTO Current_Floor(Floor_id, Date_Time) SELECT Floors.Floor_id, '"+ date_time + "' FROM Floors WHERE Floors.Floor_number=?";
                
                OleDbCommand command = new OleDbCommand(queryString, conn);
                command.Parameters.AddWithValue("@a",State);

                conn.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Floor Updated");
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!!! Something is wrong with Database");

            }
            
        }
    }
}
