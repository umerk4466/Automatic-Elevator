﻿namespace Elevator
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
            this.MainTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.Floor0_tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.elevator_left_corner_pictureBox_floor0 = new System.Windows.Forms.PictureBox();
            this.elevator_right_corner_pictureBox_floor0 = new System.Windows.Forms.PictureBox();
            this.elevator_left_side_pictureBox_floor0 = new System.Windows.Forms.PictureBox();
            this.elevator_right_side_pictureBox_floor0 = new System.Windows.Forms.PictureBox();
            this.elevator_floor0_btn_up = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.Floor1_tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.elevator_top_picturebox = new System.Windows.Forms.PictureBox();
            this.elevator_left_corner_pictureBox = new System.Windows.Forms.PictureBox();
            this.elevator_right_corner_pictureBox = new System.Windows.Forms.PictureBox();
            this.elevator_left_side_pictureBox = new System.Windows.Forms.PictureBox();
            this.elevator_right_side_pictureBox = new System.Windows.Forms.PictureBox();
            this.elevator_floor1_btn_down = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.MainTableLayoutPanel.SuspendLayout();
            this.Floor0_tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_corner_pictureBox_floor0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_corner_pictureBox_floor0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_side_pictureBox_floor0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_side_pictureBox_floor0)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Floor1_tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_top_picturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_corner_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_corner_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_side_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_side_pictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MainTableLayoutPanel
            // 
            this.MainTableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.MainTableLayoutPanel.ColumnCount = 2;
            this.MainTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.52632F));
            this.MainTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 89.47369F));
            this.MainTableLayoutPanel.Controls.Add(this.Floor0_tableLayoutPanel, 1, 1);
            this.MainTableLayoutPanel.Controls.Add(this.Floor1_tableLayoutPanel, 1, 0);
            this.MainTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayoutPanel.Margin = new System.Windows.Forms.Padding(0);
            this.MainTableLayoutPanel.Name = "MainTableLayoutPanel";
            this.MainTableLayoutPanel.RowCount = 2;
            this.MainTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.MainTableLayoutPanel.Size = new System.Drawing.Size(1008, 666);
            this.MainTableLayoutPanel.TabIndex = 0;
            // 
            // Floor0_tableLayoutPanel
            // 
            this.Floor0_tableLayoutPanel.BackColor = System.Drawing.Color.Transparent;
            this.Floor0_tableLayoutPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Floor0_tableLayoutPanel.BackgroundImage")));
            this.Floor0_tableLayoutPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Floor0_tableLayoutPanel.ColumnCount = 6;
            this.Floor0_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.Floor0_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.Floor0_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Floor0_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.Floor0_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Floor0_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Floor0_tableLayoutPanel.Controls.Add(this.elevator_left_corner_pictureBox_floor0, 2, 1);
            this.Floor0_tableLayoutPanel.Controls.Add(this.elevator_right_corner_pictureBox_floor0, 4, 1);
            this.Floor0_tableLayoutPanel.Controls.Add(this.elevator_left_side_pictureBox_floor0, 2, 2);
            this.Floor0_tableLayoutPanel.Controls.Add(this.elevator_right_side_pictureBox_floor0, 4, 2);
            this.Floor0_tableLayoutPanel.Controls.Add(this.elevator_floor0_btn_up, 1, 2);
            this.Floor0_tableLayoutPanel.Controls.Add(this.panel2, 3, 0);
            this.Floor0_tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Floor0_tableLayoutPanel.Location = new System.Drawing.Point(111, 334);
            this.Floor0_tableLayoutPanel.Margin = new System.Windows.Forms.Padding(0);
            this.Floor0_tableLayoutPanel.Name = "Floor0_tableLayoutPanel";
            this.Floor0_tableLayoutPanel.RowCount = 5;
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19F));
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1F));
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Floor0_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Floor0_tableLayoutPanel.Size = new System.Drawing.Size(894, 329);
            this.Floor0_tableLayoutPanel.TabIndex = 2;
            // 
            // elevator_left_corner_pictureBox_floor0
            // 
            this.elevator_left_corner_pictureBox_floor0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_left_corner_pictureBox_floor0.BackgroundImage")));
            this.elevator_left_corner_pictureBox_floor0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_left_corner_pictureBox_floor0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_left_corner_pictureBox_floor0.Location = new System.Drawing.Point(330, 62);
            this.elevator_left_corner_pictureBox_floor0.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_left_corner_pictureBox_floor0.Name = "elevator_left_corner_pictureBox_floor0";
            this.elevator_left_corner_pictureBox_floor0.Size = new System.Drawing.Size(89, 49);
            this.elevator_left_corner_pictureBox_floor0.TabIndex = 1;
            this.elevator_left_corner_pictureBox_floor0.TabStop = false;
            // 
            // elevator_right_corner_pictureBox_floor0
            // 
            this.elevator_right_corner_pictureBox_floor0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_right_corner_pictureBox_floor0.BackgroundImage")));
            this.elevator_right_corner_pictureBox_floor0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_right_corner_pictureBox_floor0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_right_corner_pictureBox_floor0.Location = new System.Drawing.Point(714, 62);
            this.elevator_right_corner_pictureBox_floor0.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_right_corner_pictureBox_floor0.Name = "elevator_right_corner_pictureBox_floor0";
            this.elevator_right_corner_pictureBox_floor0.Size = new System.Drawing.Size(89, 49);
            this.elevator_right_corner_pictureBox_floor0.TabIndex = 2;
            this.elevator_right_corner_pictureBox_floor0.TabStop = false;
            // 
            // elevator_left_side_pictureBox_floor0
            // 
            this.elevator_left_side_pictureBox_floor0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_left_side_pictureBox_floor0.BackgroundImage")));
            this.elevator_left_side_pictureBox_floor0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_left_side_pictureBox_floor0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_left_side_pictureBox_floor0.Location = new System.Drawing.Point(330, 111);
            this.elevator_left_side_pictureBox_floor0.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_left_side_pictureBox_floor0.Name = "elevator_left_side_pictureBox_floor0";
            this.elevator_left_side_pictureBox_floor0.Size = new System.Drawing.Size(89, 148);
            this.elevator_left_side_pictureBox_floor0.TabIndex = 3;
            this.elevator_left_side_pictureBox_floor0.TabStop = false;
            // 
            // elevator_right_side_pictureBox_floor0
            // 
            this.elevator_right_side_pictureBox_floor0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_right_side_pictureBox_floor0.BackgroundImage")));
            this.elevator_right_side_pictureBox_floor0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_right_side_pictureBox_floor0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_right_side_pictureBox_floor0.Location = new System.Drawing.Point(714, 111);
            this.elevator_right_side_pictureBox_floor0.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_right_side_pictureBox_floor0.Name = "elevator_right_side_pictureBox_floor0";
            this.elevator_right_side_pictureBox_floor0.Size = new System.Drawing.Size(89, 148);
            this.elevator_right_side_pictureBox_floor0.TabIndex = 4;
            this.elevator_right_side_pictureBox_floor0.TabStop = false;
            // 
            // elevator_floor0_btn_up
            // 
            this.elevator_floor0_btn_up.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.elevator_floor0_btn_up.BackColor = System.Drawing.Color.Transparent;
            this.elevator_floor0_btn_up.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_floor0_btn_up.BackgroundImage")));
            this.elevator_floor0_btn_up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_floor0_btn_up.Location = new System.Drawing.Point(274, 165);
            this.elevator_floor0_btn_up.Margin = new System.Windows.Forms.Padding(2);
            this.elevator_floor0_btn_up.MaximumSize = new System.Drawing.Size(50, 40);
            this.elevator_floor0_btn_up.MinimumSize = new System.Drawing.Size(50, 40);
            this.elevator_floor0_btn_up.Name = "elevator_floor0_btn_up";
            this.elevator_floor0_btn_up.Size = new System.Drawing.Size(50, 40);
            this.elevator_floor0_btn_up.TabIndex = 5;
            this.elevator_floor0_btn_up.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(419, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.Floor0_tableLayoutPanel.SetRowSpan(this.panel2, 3);
            this.panel2.Size = new System.Drawing.Size(295, 259);
            this.panel2.TabIndex = 6;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(0, 62);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(295, 49);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radioButton1.Location = new System.Drawing.Point(0, 246);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(0);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(295, 13);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Visible = false;
            // 
            // Floor1_tableLayoutPanel
            // 
            this.Floor1_tableLayoutPanel.BackColor = System.Drawing.Color.Transparent;
            this.Floor1_tableLayoutPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Floor1_tableLayoutPanel.BackgroundImage")));
            this.Floor1_tableLayoutPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Floor1_tableLayoutPanel.ColumnCount = 6;
            this.Floor1_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.Floor1_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.Floor1_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Floor1_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.Floor1_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Floor1_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Floor1_tableLayoutPanel.Controls.Add(this.elevator_top_picturebox, 3, 1);
            this.Floor1_tableLayoutPanel.Controls.Add(this.elevator_left_corner_pictureBox, 2, 1);
            this.Floor1_tableLayoutPanel.Controls.Add(this.elevator_right_corner_pictureBox, 4, 1);
            this.Floor1_tableLayoutPanel.Controls.Add(this.elevator_left_side_pictureBox, 2, 2);
            this.Floor1_tableLayoutPanel.Controls.Add(this.elevator_right_side_pictureBox, 4, 2);
            this.Floor1_tableLayoutPanel.Controls.Add(this.elevator_floor1_btn_down, 1, 2);
            this.Floor1_tableLayoutPanel.Controls.Add(this.panel1, 3, 2);
            this.Floor1_tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Floor1_tableLayoutPanel.Location = new System.Drawing.Point(111, 3);
            this.Floor1_tableLayoutPanel.Margin = new System.Windows.Forms.Padding(0);
            this.Floor1_tableLayoutPanel.Name = "Floor1_tableLayoutPanel";
            this.Floor1_tableLayoutPanel.RowCount = 5;
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19F));
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1F));
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Floor1_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Floor1_tableLayoutPanel.Size = new System.Drawing.Size(894, 328);
            this.Floor1_tableLayoutPanel.TabIndex = 1;
            // 
            // elevator_top_picturebox
            // 
            this.elevator_top_picturebox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_top_picturebox.BackgroundImage")));
            this.elevator_top_picturebox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_top_picturebox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_top_picturebox.Location = new System.Drawing.Point(419, 62);
            this.elevator_top_picturebox.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_top_picturebox.Name = "elevator_top_picturebox";
            this.elevator_top_picturebox.Size = new System.Drawing.Size(295, 49);
            this.elevator_top_picturebox.TabIndex = 0;
            this.elevator_top_picturebox.TabStop = false;
            // 
            // elevator_left_corner_pictureBox
            // 
            this.elevator_left_corner_pictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_left_corner_pictureBox.BackgroundImage")));
            this.elevator_left_corner_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_left_corner_pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_left_corner_pictureBox.Location = new System.Drawing.Point(330, 62);
            this.elevator_left_corner_pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_left_corner_pictureBox.Name = "elevator_left_corner_pictureBox";
            this.elevator_left_corner_pictureBox.Size = new System.Drawing.Size(89, 49);
            this.elevator_left_corner_pictureBox.TabIndex = 1;
            this.elevator_left_corner_pictureBox.TabStop = false;
            // 
            // elevator_right_corner_pictureBox
            // 
            this.elevator_right_corner_pictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_right_corner_pictureBox.BackgroundImage")));
            this.elevator_right_corner_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_right_corner_pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_right_corner_pictureBox.Location = new System.Drawing.Point(714, 62);
            this.elevator_right_corner_pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_right_corner_pictureBox.Name = "elevator_right_corner_pictureBox";
            this.elevator_right_corner_pictureBox.Size = new System.Drawing.Size(89, 49);
            this.elevator_right_corner_pictureBox.TabIndex = 2;
            this.elevator_right_corner_pictureBox.TabStop = false;
            // 
            // elevator_left_side_pictureBox
            // 
            this.elevator_left_side_pictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_left_side_pictureBox.BackgroundImage")));
            this.elevator_left_side_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_left_side_pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_left_side_pictureBox.Location = new System.Drawing.Point(330, 111);
            this.elevator_left_side_pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_left_side_pictureBox.Name = "elevator_left_side_pictureBox";
            this.elevator_left_side_pictureBox.Size = new System.Drawing.Size(89, 147);
            this.elevator_left_side_pictureBox.TabIndex = 3;
            this.elevator_left_side_pictureBox.TabStop = false;
            // 
            // elevator_right_side_pictureBox
            // 
            this.elevator_right_side_pictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_right_side_pictureBox.BackgroundImage")));
            this.elevator_right_side_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_right_side_pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elevator_right_side_pictureBox.Location = new System.Drawing.Point(714, 111);
            this.elevator_right_side_pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.elevator_right_side_pictureBox.Name = "elevator_right_side_pictureBox";
            this.elevator_right_side_pictureBox.Size = new System.Drawing.Size(89, 147);
            this.elevator_right_side_pictureBox.TabIndex = 4;
            this.elevator_right_side_pictureBox.TabStop = false;
            // 
            // elevator_floor1_btn_down
            // 
            this.elevator_floor1_btn_down.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.elevator_floor1_btn_down.BackColor = System.Drawing.Color.Transparent;
            this.elevator_floor1_btn_down.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("elevator_floor1_btn_down.BackgroundImage")));
            this.elevator_floor1_btn_down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.elevator_floor1_btn_down.Location = new System.Drawing.Point(274, 164);
            this.elevator_floor1_btn_down.Margin = new System.Windows.Forms.Padding(2);
            this.elevator_floor1_btn_down.MaximumSize = new System.Drawing.Size(50, 40);
            this.elevator_floor1_btn_down.MinimumSize = new System.Drawing.Size(50, 40);
            this.elevator_floor1_btn_down.Name = "elevator_floor1_btn_down";
            this.elevator_floor1_btn_down.Size = new System.Drawing.Size(50, 40);
            this.elevator_floor1_btn_down.TabIndex = 5;
            this.elevator_floor1_btn_down.UseVisualStyleBackColor = false;
            this.elevator_floor1_btn_down.Click += new System.EventHandler(this.elevator_floor1_btn_down_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(419, 111);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.Floor1_tableLayoutPanel.SetRowSpan(this.panel1, 3);
            this.panel1.Size = new System.Drawing.Size(295, 217);
            this.panel1.TabIndex = 6;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(0, 150);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(295, 67);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(295, 147);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 666);
            this.Controls.Add(this.MainTableLayoutPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Main_Form";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Elevator v1.0";
            this.MainTableLayoutPanel.ResumeLayout(false);
            this.Floor0_tableLayoutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_corner_pictureBox_floor0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_corner_pictureBox_floor0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_side_pictureBox_floor0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_side_pictureBox_floor0)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Floor1_tableLayoutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elevator_top_picturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_corner_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_corner_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_left_side_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elevator_right_side_pictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel Floor1_tableLayoutPanel;
        private System.Windows.Forms.PictureBox elevator_top_picturebox;
        private System.Windows.Forms.PictureBox elevator_left_corner_pictureBox;
        private System.Windows.Forms.PictureBox elevator_right_corner_pictureBox;
        private System.Windows.Forms.PictureBox elevator_left_side_pictureBox;
        private System.Windows.Forms.PictureBox elevator_right_side_pictureBox;
        private System.Windows.Forms.Button elevator_floor1_btn_down;
        private System.Windows.Forms.TableLayoutPanel Floor0_tableLayoutPanel;
        private System.Windows.Forms.PictureBox elevator_left_corner_pictureBox_floor0;
        private System.Windows.Forms.PictureBox elevator_right_corner_pictureBox_floor0;
        private System.Windows.Forms.PictureBox elevator_left_side_pictureBox_floor0;
        private System.Windows.Forms.PictureBox elevator_right_side_pictureBox_floor0;
        private System.Windows.Forms.Button elevator_floor0_btn_up;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}

